#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
				
		gpio_toggle_pin_level(LED1);
		delay_ms(96);
				
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);

		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);

		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);

		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);

		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);


		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);

		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);			
		
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED3);
		
		delay_ms(96);

		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED6);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED7);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED1);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED5);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED2);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED8);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED4);
		
		delay_ms(96);
		
		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		gpio_toggle_pin_level(LED6);
		gpio_toggle_pin_level(LED7);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(192);
		
		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		gpio_toggle_pin_level(LED6);
		gpio_toggle_pin_level(LED7);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(192);

		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		gpio_toggle_pin_level(LED6);
		gpio_toggle_pin_level(LED7);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(192);
		
		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		gpio_toggle_pin_level(LED6);
		gpio_toggle_pin_level(LED7);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(192);
		
		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		gpio_toggle_pin_level(LED6);
		gpio_toggle_pin_level(LED7);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(192);
		
		gpio_toggle_pin_level(LED1);
		gpio_toggle_pin_level(LED2);
		gpio_toggle_pin_level(LED3);
		gpio_toggle_pin_level(LED4);
		gpio_toggle_pin_level(LED5);
		gpio_toggle_pin_level(LED6);
		gpio_toggle_pin_level(LED7);
		gpio_toggle_pin_level(LED8);
		
		delay_ms(192);
	}
}
