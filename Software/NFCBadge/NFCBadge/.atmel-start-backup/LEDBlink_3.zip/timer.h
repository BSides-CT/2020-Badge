#ifndef TIMER_H
#define TIMER_H

void millis_init(void);
volatile uint32_t millis(void);

#endif
