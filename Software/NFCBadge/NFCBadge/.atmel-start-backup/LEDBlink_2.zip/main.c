#include <atmel_start.h>

/* Toggle an LED on or off */
void toggle(int led)
{
	switch (led)
	{
		case 1:
		gpio_toggle_pin_level(LED1);
		break;
		case 2:
		gpio_toggle_pin_level(LED2);
		break;
		case 3:
		gpio_toggle_pin_level(LED3);
		break;
		case 4:
		gpio_toggle_pin_level(LED4);
		break;
		case 5:
		gpio_toggle_pin_level(LED5);
		break;
		case 6:
		gpio_toggle_pin_level(LED6);
		break;
		case 7:
		gpio_toggle_pin_level(LED7);
		break;
		case 8:
		gpio_toggle_pin_level(LED8);
		break;
	}
}

/* Blink an LED for a given amount of time*/
void blink(int led, int ms)
{
	toggle(led);
	delay_ms(ms);
	toggle(led);
}

/* MAIN */
int main(void)
{
	/* Initialize MCU, drivers and middleware */
	atmel_start_init();

	/* Blink LEDs */
	while (true)
	{
		int speed = 40;
		
		/* Bounce back and forth 4 times */
		for (int x=0; x<4; x++)
		{
			/* left to right */
			for (int i=1; i<8; i++)
			{
				blink(i, speed);
				delay_ms(speed);
			}
			/* right to left */
			for (int i=8; i>1; i--)
			{
				blink(i, speed);
				delay_ms(speed);
			}
		}
		
		/* Blink all LEDs 8 times */
		for (int x=0; x<8; x++)
		{
			for (int i=1; i<=8; i++)
			{
				toggle(i);
			}
			delay_ms(speed*2);
			for (int i=1; i<=8; i++)
			{
				toggle(i);
			}
			delay_ms(speed*2);
		}
	}
}
